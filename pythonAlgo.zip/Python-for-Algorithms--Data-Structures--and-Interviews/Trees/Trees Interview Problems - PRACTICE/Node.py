class Node(object):
    def __init__(self, val=None):
        self.left = None
        self.right = None
        self.val =  val 